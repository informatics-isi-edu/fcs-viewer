make.mix.data <- function(ddata, bins, resolution){
    data.out <- matrix(0, bins, 2)
    nvals <- length(ddata)
    
    max.ddata <- max(ddata)
    min.ddata <- min(ddata)
    offset <- (max.ddata - min.ddata) / resolution
    a <- min.ddata
    inter <- ((offset + max.ddata) - (min.ddata-offset))/bins
    for( i in 1:bins){
        a <- a + inter
        data.out[i,1] <- a
    }
    
    
    for (i in 1:nvals){
        k <- 1
        calc.x <- ddata[i] - min.ddata
        while(calc.x > inter){
            calc.x <- calc.x - inter
            k <- k + 1
        }
        data.out[k,2] <- data.out[k,2] + 1
    }
    data.out <- as.mixdata(as.data.frame(data.out))
    data.out
}

ggplot.mix <- function (x, mixpar = NULL, dist = "norm", root = FALSE, ytop = NULL, 
                        clwd = 1, main, sub, xlab, ylab, bty, BW = FALSE, ...) 
{
    mixobj <- x
    if (inherits(mixobj, "mix")) {
        mixdat <- mixobj$mixdata
        mixpar <- mixobj$parameters
        dist <- mixobj$distribution
    }
    else mixdat <- mixobj
    black <- "black"
    blue <- "blue"
    red <- "red"
    forestgreen <- "forestgreen"
    gray = "gray"
    darkgray = "black"
    lty1 <- 1
    lty2 <- 2
    if (missing(xlab)) 
        xlab <- dimnames(mixdat)[[2]][1]
    if (missing(ylab)) {
        if (root) 
            ylab <- "Square Root of Probability Density"
        else ylab <- "Probability Density"
    }
    if (missing(bty)) 
        bty <- "o"
    ntot <- sum(mixdat[, 2])
    m <- nrow(mixdat)
    iwid <- mixdat[2:(m - 1), 1] - mixdat[1:(m - 2), 1]
    iwid <- c(2 * iwid[1], iwid, 2 * iwid[m - 2])
    if (mixdat[1, 1] > 0 & !is.na(match(dist, c("lnorm", "gamma", 
                                                "weibull")))) 
        iwid[1] <- min(iwid[1], mixdat[1, 1])
    if (mixdat[1, 1] > 0 & !is.na(match(dist, c("binom", "nbinom", 
                                                "pois")))) 
        if (mixdat[1, 1] == min(iwid[1], mixdat[1, 1])) 
            iwid[1] <- mixdat[1, 1] + 0.5
    idens <- (mixdat[, 2]/iwid)/ntot
    hx <- rep(c(mixdat[1, 1] - iwid[1], mixdat[-m, 1], mixdat[m - 
                                                                  1, 1] + iwid[m]), rep(2, m + 1))
    hy <- c(0, rep(idens, rep(2, m)), 0)
    if (!is.null(mixpar)) {
        k <- nrow(mixpar)
        if (ncol(mixpar) > 3) 
            par3 <- mixpar[, 4]
        else par3 <- rep(0, k)
        prop <- mixpar[, 1]                             # establish proportion
        if (dist == "norm") {
            par1 <- mixpar[, 2]
            par2 <- mixpar[, 3]
            if (missing(sub)) 
                sub <- "Normal Mixture"
        }
        else if (dist == "lnorm") {
            par2 <- sqrt(log((mixpar[, 3]/(mixpar[, 2] - par3))^2 + 
                                 1))
            par1 <- log(mixpar[, 2] - par3) - (par2^2)/2
            if (missing(sub)) 
                sub <- "Lognormal Mixture"
        }
        else if (dist == "gamma") {
            par1 <- ((mixpar[, 2] - par3)/mixpar[, 3])^2
            par2 <- (mixpar[, 2] - par3)/(mixpar[, 3]^2)
            if (missing(sub)) 
                sub <- "Gamma Mixture"
        }
        else if (dist == "weibull") {
            par <- weibullpar(mixpar[, 2], mixpar[, 3], par3)
            par1 <- par$shape
            par2 <- par$scale
            if (missing(sub)) 
                sub <- "Weibull Mixture"
        }
        else if (dist == "binom") {
            par1 <- ceiling(mixpar[, 2]^2/(mixpar[, 2] - mixpar[, 
                                                                3]^2))
            par2 <- 1 - mixpar[, 3]^2/mixpar[, 2]
            if (missing(sub)) 
                sub <- "Binomial Mixture"
        }
        else if (dist == "nbinom") {
            par1 <- mixpar[, 2]^2/(mixpar[, 3]^2 - mixpar[, 2])
            if (missing(sub)) 
                sub <- "Negative Binomial Mixture"
        }
        else if (dist == "pois") {
            par1 <- mixpar[, 2]
            if (missing(sub)) 
                sub <- "Poisson Mixture"
        }
        else {
            par1 <- mixpar[, 2]
            par2 <- mixpar[, 3]
            warning(paste("Unknown distribution ", dist, ", using normal", 
                          sep = ""))
            dist <- "norm"
        }
        if (root) {
            mwid <- c(mixdat[1, 1] - iwid[1], mixdat[-m, 1]) + 
                iwid/2
            rf <- 2
        }
        else {
            mwid <- 0
            rf <- 1
        }
        lgr <- seq(hx[1], hx[length(hx)], length = 400)                     # sequence for X axis used for dnorm
        if (!is.na(match(dist, c("binom", "nbinom", "pois")))) 
            lgr <- floor(lgr[1]):ceiling(lgr[length(lgr)])
        rc <- TRUE
        for (j in 1:rf) {
            pdf <- matrix(0, nrow = k, ncol = length(lgr))
            for (i in 1:k) {                                                # cycle through # peaks k
                if (dist == "norm") 
                    pdfi <- dnorm(lgr, par1[i], par2[i])                    # generate pred y
                else if (dist == "lnorm") 
                    pdfi <- dlnorm(lgr - par3[i], par1[i], par2[i])
                else if (dist == "gamma") 
                    pdfi <- dgamma(lgr - par3[i], par1[i], par2[i])
                else if (dist == "weibull") 
                    pdfi <- dweibull(lgr - par3[i], par1[i], par2[i])
                else if (dist == "binom") 
                    pdfi <- dbinom(round(lgr, 0), par1[i], par2[i])
                else if (dist == "nbinom") 
                    pdfi <- dnbinom(round(lgr, 0), par1[i], mu = mixpar[i, 
                                                                        2])
                else if (dist == "pois") 
                    pdfi <- dpois(round(lgr, 0), par1[i])
                pdf[i, ] <- prop[i] * pdfi
            }
            if (rc) {
                lgr1 <- lgr
                lgr <- mwid
                pdf1 <- pdf
                pdfm1 <- apply(pdf1, 2, sum)            # gives the sum of individual
                dfF <- as.data.frame(cbind(lgr1))
                for(f in 1:nrow(pdf1)) dfF <- cbind(dfF, pdf1[f,])
                dfF <- cbind(dfF, pdfm1)
                rc <- FALSE
            }
        }
        if (root) {
            pdfm <- apply(pdf, 2, sum)
            dif <- sqrt(pdfm) - sqrt(idens)
            hy1 <- c(0, rep(pdfm, rep(2, m)), 0)
        }
    }
    if (root) {
        if (is.null(mixpar)) {
            if (is.null(ytop)) 
                ylim <- NULL
            else ylim <- c(0, ytop)
        }
        else {
            if (is.null(ytop)) 
                ylim <- c(min(dif, 0), max(sqrt(hy)))
            else ylim <- c(min(dif, 0), ytop)
        }
        plot(hx, sqrt(hy), type = "n", ylim = ylim, col = black, 
             xlab = xlab, ylab = ylab, bty = bty, ...)
    }
    else {
        if (is.null(ytop)) 
            ylim <- NULL
        else ylim <- c(0, ytop)
        ## plot data
        #plot(hx, hy, type = "n", ylim = ylim, col = black, xlab = xlab,
         #    ylab = ylab, bty = bty, ...)
        dfp <- data.frame(x=hx, y=hy)
        p <- ggplot(data=dfp, aes(x=x, y=y))

    }
    title = ifelse(missing(main), "", main) 
    subtitle = ifelse(missing(sub), "", sub)
    if (root & is.null(mixpar)) 
        lines(hx, sqrt(hy), col = ifelse(BW, black, blue))
    else if (root & !is.null(mixpar)) {
        lines(hx, sqrt(hy1), col = ifelse(BW, black, blue))
        rect(c(mixdat[1, 1] - iwid[1], mixdat[-m, 1]), rep(0, 
                                                           m), c(mixdat[-m, 1], mixdat[m - 1, 1] + iwid[m]), 
             dif, col = ifelse(BW, gray, blue))
    }
    else if (!root) 
        #lines(hx, hy, col = ifelse(BW, black, blue))     # draw the histogram as lines
        p1 <- p + geom_path()
    #lines(hx[c(1, length(hx))], c(0, 0), col = black)    # draw a baseline
    p2 <- p1 + geom_hline(yintercept=0)
    p3 <- p2
    if (!is.null(mixpar)) {
        for (i in 1:k) {                                        ## plots each fit line
            if (root) 
                lines(lgr1, sqrt(pdf1[i, ]), col = ifelse(BW, 
                                                          darkgray, red), lty = ifelse(BW, lty2, 1), 
                      lwd = 1 * clwd)
            else #lines(lgr1, pdf1[i, ], col = ifelse(BW, darkgray, 
                  #                                   red), lty = ifelse(BW, lty2, 1), lwd = 1 * clwd)  # draws fit
            if (i==1) {data1 <- dfF[,c(1,i+1)]; p3 <- p3 + geom_path(data=data1, aes(x=data1[,1], y=data1[,2]), colour=i + 1)}
            if (i==2) {data2 <- dfF[,c(1, i+1)]; p3 <- p3 + geom_path(data=data2, aes(x=data2[,1], y=data2[,2]), colour=i + 1)}
            #points(mixpar[i, 2], 0, pch = 17, col = ifelse(BW, 
              #                                             darkgray, red))                              # marks mean
            p3 <- p3 + geom_vline(xintercept=mixpar[i,2], colour=i + 1)
            p3 <- p3 + annotate("text", label= paste("MFI = ", round(10^mixpar[i,2],0), sep=""), x = mixpar[i,2] + 0.5, y = max(dfF[,i+1]), 
                                size=8, colour=i + 1)
        }
        if (k > 1){
            if (root) 
                lines(lgr1, sqrt(pdfm1), col = ifelse(BW, black, 
                                                      forestgreen), lty = ifelse(BW, lty1, 1), lwd = 2 * 
                          clwd)
            else #lines(lgr1, pdfm1, col = ifelse(BW, black, forestgreen), 
                  #     lty = ifelse(BW, lty1, 1), lwd = 2 * clwd)
                dataC <- dfF[,c(1,ncol(dfF))]; p4 <- p3 + geom_path(data=dataC, aes(x=dataC[,1], y=dataC[,2]), colour = "green")
            out <- p4
        }
        out <- p3
    }
    return(out)
}