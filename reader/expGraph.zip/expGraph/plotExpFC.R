library('prada')
library('flowCore')
library('mixtools')
library('ggplot2')
library('mixdist')
library('plyr')
library('gridExtra')

### threshold values  ### should be user adjustable with defaults 
xThresh <- 20
yThresh <- 30
xThreshL <- log(xThresh, 10)
yThreshL <- log(yThresh, 10)

### define directory and file name for analysis
dataDir <- "data/expression"
fileName <- 'exp_122115kv1.EP5'                 # can we store directory and filename in db to feed to this script?
filename1 = paste(fileName, "png", sep=".")     # output file name 


### read in data for processing 
sample = readFCS(paste(dataDir, paste(fileName, "FCS", sep="."), sep="/"))
fdat = exprs(sample)
d.f <- data.frame( Expression = fdat[, "GRN-HLog"], CellDeath = fdat[, "RED-HLog"], Class = NA ) 
d.f[d.f$Expression<xThreshL & d.f$CellDeath>yThreshL,3] <- "NEDC"
d.f[d.f$Expression<xThreshL & d.f$CellDeath<yThreshL,3] <- "NELC"
d.f[d.f$Expression>xThreshL & d.f$CellDeath>yThreshL,3] <- "EDC"
d.f[d.f$Expression>xThreshL & d.f$CellDeath<yThreshL,3] <- "ELC"
d.f$Class <- as.factor(d.f$Class)



### Get stats 

### viability
totalCnt <- dim(d.f)[1]
viability <- 100 - ((dim(d.f[d.f$Class=="NEDC" | d.f$Class=="EDC",])[1] / totalCnt) * 100)
expViability <- (dim(d.f[d.f$Class=="ELC",])[1] / dim(d.f[d.f$Class=="ELC" | d.f$Class=="EDC",])[1]) * 100
expPercent <- (dim(d.f[d.f$Class=="ELC",])[1] / dim(d.f[d.f$Class=="NELC" | d.f$Class=="ELC",])[1]) * 100

### expression levels
statTable <- data.frame(PercentTotal=c(round((dim(d.f[d.f$Class=="NELC",])[1] / totalCnt) * 100, 0) , round((dim(d.f[d.f$Class=="ELC",])[1] / totalCnt) * 100, 0), 
                                       round((dim(d.f[d.f$Class=="EDC",])[1] / totalCnt) * 100, 0), round((dim(d.f[d.f$Class=="ELC" | d.f$Class=="EDC",])[1] / totalCnt) * 100, 0)),
                        Mean= c(round(10^(mean(d.f[d.f$Class=="NELC",'Expression'])), 0), round(10^(mean(d.f[d.f$Class=="ELC",'Expression'])), 0), 
                                round(10^(mean(d.f[d.f$Class=="EDC",'Expression'])), 0), round(10^(mean(d.f[d.f$Class=="ELC" | d.f$Class=="EDC",'Expression'])), 0) ),
                        Median=c(round(10^(median(d.f[d.f$Class=="NELC",'Expression'])), 0), round(10^(median(d.f[d.f$Class=="ELC",'Expression'])), 0), 
                                 round(10^(median(d.f[d.f$Class=="EDC",'Expression'])), 0), round(10^(median(d.f[d.f$Class=="ELC" | d.f$Class=="EDC",'Expression'])), 0) )
                        )
rownames(statTable) <- c("NELC", "ELC", "EDC", "Expressing")


p <- ggplot(data=d.f, aes(x=Expression, y=CellDeath))
t1 <- p + annotation_custom(tableGrob(statTable), xmin=0, xmax=2, ymin=1.75, ymax=2.75)
g1 <- t1 + geom_point(size=5, aes(color=Class, alpha=2.5 - CellDeath))
g1

### fit distribution to unimodal and bimodal and decide which is better
expData <- d.f[d.f$Class=="NELC" | d.f$Class=="ELC", 'Expression']
expDataPlot <- d.f[d.f$Class=="NELC" | d.f$Class=="ELC", ]
mix.dist.hist <- make.mix.data(expData, 50, 10)
fitDist1 <- mix(mix.dist.hist, mixparam(mu=mean(expData), sigma=sd(expData)), 'norm')

expDataNELC <- d.f[d.f$Class=="NELC", 'Expression']
expDataELC <- d.f[d.f$Class=="ELC", 'Expression']
mix.dist.hist <- make.mix.data(expData, 50,10)
fitDist2 <- mix(mix.dist.hist, mixparam(mu=c(mean(expDataNELC), mean(expDataELC)), sigma=c(sd(expDataNELC), sd(expDataELC))), "norm")

fitStat <- rbind(c(fitDist1$chisq, fitDist2$chisq), c(fitDist1$P, fitDist2$P))
## decision

if (fitStat[2,2] < 0.01 & fitStat[1,2] < fitStat[1,1]) {
    statELC <- c(fitDist2$parameters[2,'mu'], 
                 fitDist2$parameters[2,'sigma'],
                 fitDist2$parameters[2,'pi'])
    plot <- ggplot.mix(fitDist2)
} else {
    statELC <- c(fitDist1$parameters[1,'mu'],
                 fitDist1$parameters[1,'sigma'],
                 fitDist1$parameters[1,'pi'])
    plot <- ggplot.mix(fitDist1)
}
                 